package com.noloop.wallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val pickVideo = 1001
    private val prefs by lazy { getSharedPreferences("wallpaper", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }
        val title = TextView(this).apply {
            text = "NoLoop Wallpaper\n\nخلفية فيديو بدون تكرار"
            textSize = 24f
        }
        val choose = Button(this).apply {
            text = "اختيار فيديو"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "video/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(intent, pickVideo)
            }
        }
        val apply = Button(this).apply {
            text = "معاينة وتعيين الخلفية"
            setOnClickListener {
                if (prefs.getString("video_uri", null) == null) {
                    Toast.makeText(this@MainActivity, "اختر فيديو أولاً", Toast.LENGTH_SHORT).show()
                } else {
                    val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                        putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            ComponentName(this@MainActivity, VideoWallpaperService::class.java))
                    }
                    startActivity(intent)
                }
            }
        }
        val note = TextView(this).apply {
            text = "\nملاحظة: عند شاشة اختيار الخلفية، اختر تطبيق الخلفية على شاشة القفل فقط إذا أتاح ColorOS هذا الخيار."
            textSize = 14f
        }
        layout.addView(title); layout.addView(choose); layout.addView(apply); layout.addView(note)
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideo && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                prefs.edit().putString("video_uri", uri.toString()).apply()
                Toast.makeText(this, "تم اختيار الفيديو", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(this, "تعذر حفظ صلاحية الفيديو. جرّب اختيار ملف آخر.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
