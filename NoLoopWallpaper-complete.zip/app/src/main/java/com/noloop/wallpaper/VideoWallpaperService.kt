package com.noloop.wallpaper

import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.media.MediaPlayer
import android.net.Uri
import android.content.Context

class VideoWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine() {
        private var player: MediaPlayer? = null
        private var visibleNow = false

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (visibleNow) startFromBeginning(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            visibleNow = visible
            if (visible) {
                startFromBeginning(surfaceHolder)
            } else {
                releasePlayer()
            }
        }

        private fun startFromBeginning(holder: SurfaceHolder) {
            releasePlayer()
            val raw = getSharedPreferences("wallpaper", Context.MODE_PRIVATE)
                .getString("video_uri", null) ?: return
            try {
                val mp = MediaPlayer()
                player = mp
                mp.setDataSource(this@VideoWallpaperService, Uri.parse(raw))
                mp.setDisplay(holder)
                mp.isLooping = false
                mp.setOnPreparedListener { if (visibleNow) it.start() }
                // MediaPlayer normally holds the final decoded frame when playback completes.
                mp.setOnCompletionListener { /* Intentionally do not restart. */ }
                mp.setOnErrorListener { _, _, _ -> releasePlayer(); true }
                mp.prepareAsync()
            } catch (_: Exception) {
                releasePlayer()
            }
        }

        private fun releasePlayer() {
            try { player?.setOnPreparedListener(null); player?.setOnCompletionListener(null); player?.release() } catch (_: Exception) {}
            player = null
        }

        override fun onDestroy() {
            visibleNow = false
            releasePlayer()
            super.onDestroy()
        }
    }
}
