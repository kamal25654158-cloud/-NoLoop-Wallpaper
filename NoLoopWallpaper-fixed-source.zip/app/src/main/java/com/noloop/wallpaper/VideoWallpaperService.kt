package com.noloop.wallpaper

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder

class VideoWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine(), SurfaceHolder.Callback {
        private var player: MediaPlayer? = null
        private var isVisible = false
        private var hasSurface = false
        private var destroyed = false

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            surfaceHolder.addCallback(this)
        }

        override fun surfaceCreated(holder: SurfaceHolder) {
            hasSurface = true
            startIfReady(holder)
        }

        override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            hasSurface = true
            startIfReady(holder)
        }

        override fun surfaceDestroyed(holder: SurfaceHolder) {
            hasSurface = false
            releasePlayer()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            isVisible = visible
            if (visible) {
                startIfReady(surfaceHolder)
            } else {
                releasePlayer()
            }
        }

        private fun startIfReady(holder: SurfaceHolder) {
            if (destroyed || !isVisible || !hasSurface || !holder.surface.isValid || player != null) return

            val savedUri = getSharedPreferences("wallpaper", Context.MODE_PRIVATE)
                .getString("video_uri", null) ?: return

            try {
                val mp = MediaPlayer()
                player = mp
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                        .build()
                )
                mp.setVolume(0f, 0f)
                mp.setDataSource(this@VideoWallpaperService, Uri.parse(savedUri))
                mp.setDisplay(holder)
                mp.isLooping = false
                mp.setOnPreparedListener { prepared ->
                    if (isVisible && hasSurface && !destroyed) {
                        try { prepared.start() } catch (e: Exception) {
                            Log.e("NoLoopWallpaper", "Could not start video", e)
                            releasePlayer()
                        }
                    } else {
                        releasePlayer()
                    }
                }
                mp.setOnCompletionListener { /* Keep the final frame; never restart. */ }
                mp.setOnErrorListener { _, what, extra ->
                    Log.e("NoLoopWallpaper", "MediaPlayer error: $what / $extra")
                    releasePlayer()
                    true
                }
                mp.prepareAsync()
            } catch (e: Exception) {
                Log.e("NoLoopWallpaper", "Unable to load selected video", e)
                releasePlayer()
            }
        }

        private fun releasePlayer() {
            val old = player
            player = null
            try {
                old?.setOnPreparedListener(null)
                old?.setOnCompletionListener(null)
                old?.setOnErrorListener(null)
                old?.release()
            } catch (e: Exception) {
                Log.w("NoLoopWallpaper", "Error releasing player", e)
            }
        }

        override fun onDestroy() {
            destroyed = true
            isVisible = false
            surfaceHolder.removeCallback(this)
            releasePlayer()
            super.onDestroy()
        }
    }
}
